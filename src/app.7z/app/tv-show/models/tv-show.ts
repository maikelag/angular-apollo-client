export class TvShow {
    id?: string;
    title: string;
    description: string;
    scoring: number;
    actor: string;
    image?: any;

    aguacate(): string {
        return 'Aguacate';
    }
}
